<?php
// CHỈ API THẺ QUA THECARD1S.VN 
// LINK KẾT NỐI LÀ : https://domaincuaban/API/callback.php
define('PARTNER_KEY', '9763cadadd333b6e2eaa9132028f077b'); // Your partner key
define('PARTNER_ID', '1219766609'); // Replace with your actual partner ID
define('TELEGRAM_BOT_TOKEN', '7727342554:AAHH2WSmMta-77x62HCp8fSn9DmvMJzwdRk'); // Replace with your Telegram Bot Token
define('TELEGRAM_CHAT_ID', '5540480097'); // Replace with your Telegram Chat ID
define('LOG_FILE', 'log.txt'); // Log file location
?>