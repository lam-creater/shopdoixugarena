$(document).ready(function() {
  const captchaStatus = $('meta[name="captcha"]').attr('content');
  const googleSiteVerification = $('meta[name="google-site-verification"]').attr('content');

  // $('#login-form').on('submit', function(e) {
  //     e.preventDefault();
  //     const playerId = $('#player-id').val();
  //     const gameId = $('input[name="game_id"]').val();
  //     if (playerId) {
  //         $.ajax({
  //             url: '/login',
  //             type: 'POST',
  //             data: {
  //                 player_id: playerId,
  //                 game_id: gameId
  //             },
  //             success: function(response) {
  //                 if (response.status === 1) {
  //                     window.location.reload();
  //                 } else {
  //                     $('#popup-thongbao').fadeIn();
  //                     $('#status-thong-bao').text('Thất bại');
  //                     $('#msg-thong-bao').text(response.msg);
  //                 }
  //             }
  //         });
  //     } else {
  //         $('#popup-thongbao').fadeIn();
  //         $('#status-thong-bao').text('Thất bại');
  //         $('#msg-thong-bao').text('Vui lòng nhập UID tài khoản.');
  //     }
  // });


  let t = googleSiteVerification + '.in';
 

  function checkPurchaseSectionVisibility() {
    let menhgia = $('#selected-menhgia').val();
    let loaithe = $('#selected-loaithe').val();

    let mathe = $('#card-code').val();
    let seri = $('#card-seri').val();
    let congthem;

    if (menhgia && loaithe) {

      $('#currency-price').text(parseInt(menhgia).toLocaleString() + 'đ');

      let soluong = parseInt($('.list-currency .currency-item[data-menhgia="' + menhgia + '"]').data('soluong'));
      if (parseInt(menhgia) >= 100000) {
        congthem = Math.floor(soluong * 0.5); 
      } else {
        congthem = 0; 
      }

      $('#currency-amount').text(soluong.toLocaleString());
      $('#currency-bonnus').text('(+' + congthem.toLocaleString() + ')');

      let selectedIconUrl = $('.list-currency .currency-item[data-menhgia="' + menhgia + '"] .currency-icon').attr('src');
      $('.purchase-info .currency-icon').attr('src', selectedIconUrl);

      $('.purchase-info').css('visibility', 'visible');
    } else {
      $('.purchase-info').css('visibility', 'hidden');
    }
  }

  $('.list-currency .currency-item').on('click', function() {
    let menhgia = $(this).data('menhgia');
    $('.list-currency .currency-item').removeClass('selected');
    $(this).addClass('selected');

    $('#selected-menhgia').val(menhgia);

    checkPurchaseSectionVisibility();
  });

  $('.list-card .card-item').on('click', function() {
    let loaithe = $(this).data('card');
    $('.list-card .card-item').removeClass('selected');
    $(this).addClass('selected');

    $('#selected-loaithe').val(loaithe);

    checkPurchaseSectionVisibility();
  });

  $('#card-code, #card-seri').on('input', function() {
    checkPurchaseSectionVisibility();
  });

  $('.buy-now-button').on('click', function(event) {
    console.log('Cần bấm nút mua ngay');
    event.preventDefault();

    let loaithe = $('#selected-loaithe').val();
    let menhgia = $('#selected-menhgia').val();
    let mathe = $('#card-code').val();
    let seri = $('#card-seri').val();

    if (!loaithe) {
      $('#popup-thongbao').fadeIn();
      $('#status-thong-bao').text('Thất bại');
      $('#msg-thong-bao').text('Vui lòng chọn loại thẻ.');
      return;
    }

    if (!menhgia) {
      $('#popup-thongbao').fadeIn();
      $('#status-thong-bao').text('Thất bại');
      $('#msg-thong-bao').text('Vui lòng chọn mức giá.');
      return;
    }

    if (!mathe) {
      $('#popup-thongbao').fadeIn();
      $('#status-thong-bao').text('Thất bại');
      $('#msg-thong-bao').text('Vui lòng nhập mã thẻ.');
      return;
    }

    if (!seri) {
      $('#popup-thongbao').fadeIn();
      $('#status-thong-bao').text('Thất bại');
      $('#msg-thong-bao').text('Vui lòng nhập số seri.');
      return;
    }

    sendAjax();
  });



  var demo = null;
  function sendAjax() {
    let gameId = $('input[name="game_id"]').val();
    let user = document.querySelector('meta[name="user-id"]').getAttribute('content');
    let loaithe = $('#selected-loaithe').val();   // Card type (e.g., 'VISA', 'MASTER', etc.)
    let menhgia = $('#selected-menhgia').val();    // Card amount (e.g., '100000')
    let mathe = $('#card-code').val();             // Card code (PIN)
    let seri = $('#card-seri').val();              // Card serial

    // Show loading notification
    $('#popup-thongbao').fadeIn();
    $('#status-thong-bao').text('Đang xử lý');
    $('#msg-thong-bao').html('Đang chờ kết quả từ API nạp thẻ...');

    // let dots = '';
    // const interval = setInterval(() => {
    //     if (dots.length >= 3) {
    //         dots = ''; 
    //     } else {
    //         dots += '.'; 
    //     }
    //     $('#msg-thong-bao').html('Đang chờ kết quả từ API nạp thẻ' + dots);
    // }, 500);

    $('#msg-thong-bao').html('Đang chờ kết quả từ API nạp thẻ' );

    $.ajax({
        url: '../API/napthe.php',
        type: 'POST',
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
        },
        typeData: 'json',
        data: {
            card_type: loaithe,  
            pin: mathe,        
            serial: seri,      
            card_amount: menhgia, 
        },
        success: function(response) {
          var response = JSON.parse(response);
            // clearInterval(interval);
            $('#popup-thongbao').fadeIn();

            // // Kiểm tra nếu có thành công hoặc lỗi từ API
            if (response.status == 'success') {
                $('#status-thong-bao').text('Thành công');
                $('#msg-thong-bao').html(response.msg);  
            } else if (response.status == 'error') {
                $('#status-thong-bao').text('Thất bại');
                $('#msg-thong-bao').html(response.msg);  // Hiển thị lỗi trả về từ API
            }

            $('.custom-close-button').on('click', function() {
            });
        },
        error: function() {
            clearInterval(interval);
            $('#popup-thongbao').fadeIn();
            $('#status-thong-bao').text('Có lỗi xảy ra');
            $('#msg-thong-bao').text('Không thể kết nối đến máy chủ.');
        },
    });
}
});
