<?php
include('../session.php');

$id = $_POST['id'];

if(empty($id)){
    echo json_encode(['status' => 'error', 'Vui lòng nhập UID tài khoản.']);
} else {
    $_SESSION['uid'] = $id;
}
?>